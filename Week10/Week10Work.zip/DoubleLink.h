#pragma once
#include <iostream>

using namespace std;


template <class TStruct>
struct FData
{
	//string Name; //����
	TStruct Data;
	//FData* pPrev; //ͷ
	FData* pNext; //β
};

//void AddData(FData*& Head, T val);
//void Traversal(FData<T>*& Head);