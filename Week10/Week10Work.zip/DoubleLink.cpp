#include "DoubleLink.h"

using namespace std;

//void AddData(FData*& Head, T Val) {
	//�½����һ���ڵ�
	//FData* NewData = new FData();
	//NewData->Data = Val;
	//NewData->pNext = nullptr;

	//if (Head == nullptr) {
	//	Head = NewData;
	//}
	//else {
	//	FData* Temp = Head;
	//	while (Temp->pNext != nullptr)
	//	{
	//		Temp = Temp->pNext;
	//	}
	//	Temp->pNext = NewData;
	//}

//};

//void Traversal(FData<T>* &Head) {
//	FData* Temp = Head;
//
//	while (Temp != nullptr)
//	{
//		cout << Temp->Data << endl;
//		if (Temp->pNext != nullptr) {
//			Temp = Temp->pNext;
//		}
//		else {
//			Temp = nullptr;
//		}
//	}
//
//}
