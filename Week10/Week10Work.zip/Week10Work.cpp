﻿// Week10Work.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "DoubleLink.h"

using namespace std;

template <class TFun>
void AddData(FData<TFun>*& Head, TFun Val) {
	//新建最后一个节点
	FData<TFun>* NewData = new FData<TFun>();
	NewData->Data = Val;
	NewData->pNext = nullptr;


	if (Head == nullptr) {
		Head = NewData;
	}
	else {
		FData<TFun>* Temp = Head;
		while (Temp->pNext != nullptr)
		{
			Temp = Temp->pNext;
		}
		Temp->pNext = NewData;
	}

};


template <class TNodeType>
int main()
{

	FData* Head = nullptr;

	//AddData<string>(Head, "1");
	//AddData<int>(Head, 2);
	//AddData<double>(Head, 3.1);
	//AddData<string>(Head, "4");
	//AddData(Head, "5");
}
